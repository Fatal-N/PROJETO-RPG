﻿using System;
using System.Text;
using System.Xml;
using System.Threading;
using System.Diagnostics;
class Program
{
    private const string V = "0";

    static void Main(string[] args)
    {
        Console.WriteLine("=====================================================================" +

           "\n \n\n\n\n 88      dP\"Yb  .dP\"Y8 888888    dP\"\"b8 88   88 88 88     8888b.  \n 88     dP   Yb `Ybo.\"   88     dP   `\" 88   88 88 88      8I  Yb \n 88  .o Yb   dP o.`Y8b   88     Yb  \"88 Y8   8P 88 88  .o  8I  dY \n 88ood8  YbodP  8bodP'   88      YboodP `YbodP' 88 88ood8 8888Y" + "" +
           "\n" +
           "\n" +
           "\n" +
           "\n" +
           "\n=====================================================================\n");
        Console.WriteLine("                                 |>>>\r\n                                  |\r\n                    |>>>      _  _|_  _         |>>>\r\n                    |        |;| |;| |;|        |\r\n                _  _|_  _    \\\\.    .  /    _  _|_  _\r\n               |;|_|;|_|;|    \\\\:. ,  /    |;|_|;|_|;|\r\n               \\\\..      /    ||;   . |    \\\\.    .  /\r\n                \\\\.  ,  /     ||:  .  |     \\\\:  .  /\r\n                 ||:   |_   _ ||_ . _ | _   _||:   |\r\n                 ||:  .|||_|;|_|;|_|;|_|;|_|;||:.  |\r\n                 ||:   ||.    .     .      . ||:  .|\r\n                 ||: . || .     . .   .  ,   ||:   |       \\,/\r\n                 ||:   ||:  ,  _______   .   ||: , |            /`\\\r\n                 ||:   || .   /+++++++\\    . ||:   |\r\n                 ||:   ||.    |+++++++| .    ||: . |\r\n              __ ||: . ||: ,  |+++++++|.  . _||_   |\r\n     ____--`~    '--~~__|.    |+++++__|----~    ~`---,              ___\r\n-~--~                   ~---__|,--~'                  ~~----_____-~'   `~----~~\n");

        string enter;
        Console.WriteLine("Clique em ENTER...");
        enter = Console.ReadLine();

        Console.Clear();

        // Texto a ser exibido
        string texto = "BEM-VINDO(A) AO REINO DE MORDOR !\n\n\n" +
            " Um reino devastado pela Guerra Demoníaca, a guilda mais\n" +
            "poderosa do mundo, Lost Guild se encontra fragmentada e\n" +
            "enfraquecida. O cavaleiro Gareth, um símbolo de bravura e fé\n" +
            "inabaláveis, assume a árdua missão de reconstruir o reino e\n" +
            "unir a guilda.\n\n" +
            "Sua jornada o leva às profundezas das Montanhas Sombrias,\n" +
            "onde ele encontra a lendária Espada Excalibur, capaz de\n" +
            "restaurar a força da guilda. Ao mesmo tempo, o poderoso mago\n" +
            "Eldrin, que se acreditava ter perecido na guerra, emerge das\n" +
            "sombras, gravemente ferido, mas determinado a contribuir para\n" +
            "a reconstrução de Lost Guild. Sua sabedoria e domínio das artes\n" +
            "arcanas se tornam essenciais para a guilda e para a defesa\n" +
            "do reino contra as forças demoníacas.\n\n" +
            "Em meio à busca incansável por novos membros para a guilda, Gareth e\n" +
            "Eldrin cruzam caminhos com Oliver, um elfo arqueiro de habilidades\n" +
            "excepcionais. Sua precisão mortal, agilidade sobre-humana e conhecimento\n" +
            "profundo da natureza impressionam os líderes da Lost Guild, que\n" +
            "imediatamente o reconhecem como um potencial valioso para a organização.\n\n" +
            "Com o tempo, Oliver se torna um membro integral da Lost Guild, ganhando a\n" +
            "confiança e o respeito de seus colegas. Sua precisão mortal com o arco e\n" +
            "flecha se torna uma arma crucial nas missões da guilda, eliminando inimigos\n" +
            "à distância com eficiência e furtividade. Sua agilidade e conhecimento da\n" +
            "natureza também o tornam um explorador e batedor excepcional, capaz de navegar\n" +
            "por terrenos hostis e coletar informações valiosas para a guilda.\n\n" +
            "Juntos, Gareth, Eldrin e Oliver formam um trio perfeito, cada um com seus\n" +
            "próprios talentos e habilidades únicas. A bravura de Gareth o torna um\n" +
            "líder inspirador no campo de batalha, enquanto a sabedoria de Eldrin guia\n" +
            "a guilda em momentos de crise. Oliver, por sua vez, oferece precisão mortal,\n" +
            "conhecimento da natureza e uma visão aguçada que o tornam um aliado essencial\n" +
            "em missões de reconhecimento e ataques furtivos. A guilda, agora mais forte\n" +
            "do que nunca, tem o dever de acabar com o rei demonio Azrael e seu dragão\n" +
            "Incineiro e sua aliada a bruxa Morgiana com sua horda de goblins.\n\n";        // Delay em milissegundos por letra
        int delayPorLetra = 0;         // Exibir cada letra com delay
        foreach (char letra in texto)
        {
            Console.Write(letra);
            Thread.Sleep(delayPorLetra);
        }

        Console.WriteLine("ESCOLHA UM DOS PERSONAGEMS PARA CONTINUAR A HISTÓRIA DE LOST GUILD...\n");
        Console.WriteLine("1. CAVALEIRO GARETH ");
        Console.WriteLine("2. MAGO ELDRIN ");
        Console.WriteLine("3. ARQUEIRO OLIVER ");
        int escolha;
        escolha = int.Parse(Console.ReadLine());

        switch (escolha)
        {

            case 1:
                escolha = 1;
                break;
            case 2:
                escolha = 2;
                break;
            case 3:
                escolha = 3;
                break;

        }


        Console.Clear();
        Personagem gerath = new Personagem("Jogador", 200, 30, 12);
        Personagem eldrin = new Personagem("Jogador", 200, 30, 12);
        Personagem oliver = new Personagem("Jogador", 200, 30, 12);
        Personagem goblin = new Personagem("Inimigo", 70, 20, 5);
        Personagem morgiana = new Personagem("Inimigo", 120, 15, 10);
        Personagem azraelEincinero = new Personagem("Inimigo", 300, 25, 15);

        if (escolha == 1)

        {
            Console.WriteLine("VOCÊ ESCOLHEU O CAVALEIRO GARETH !\n");
            Console.WriteLine("                      .....                      \r\n                     ^7!!!!!7^                    \r\n                    :7^^7^7^^7:                   \r\n                    .?YYY:YYJ?.                   \r\n                     7:.!^~.:7.                   \r\n                     !^.!^!.^7                    \r\n            .::^^^:~~~?!7!!^7^...:.               \r\n         :~7!~^~!~?~!!!~~^^:^7^~!.~~              \r\n       :7?~~: . 7^7^:^^^~~^^:~!^^~!!!.            \r\n      ~?:^ .:...7~!. :::^~:::   .!  J^            \r\n     ~J..:: ^.:.?!~::^::^^:::   ~.  ^~            \r\n     ^J ..^ ....!7~^ ^: ^^      !^   !:           \r\n      Y!:.:..^: :7^^  ^~~~^    .!!!.  !           \r\n      ^5^::^ ^. ^7^^  .^~^.:^^^~: 7:  ^~          \r\n       ?! .^ :: !~~^^^:^!!!~^~7^  :~   ^^         \r\n       .J^ :: ^.7:7!~!?!Y?^:^~:!.  ^~   !.        \r\n        .?~.: .7!^~!^!^~^!   ^ .!   ^~:^~!.^:^.   \r\n          !7!:.7^!   ^   .   .. ^^   7^  ^!?^~.   \r\n           :7!!!~:   .          .!   ~~^   :!^    \r\n            !^77~        .    .  ! :7?~7::. ^^    \r\n           ~:~:!    .:   ^    :  ~.  !~~Y!!7!.    \r\n          .! !.!:.. ~:  .~    !. !:  ! ^777^~!!~  \r\n          ~::~  7:::^~!:^7^^^^!!::   !:!~!.   ..  \r\n         :! ~:  7^   !.  :!    !     7!~!:        \r\n         !. !. .?:. ^^    ~: .:?.    J~!^         \r\n        ^~ .!  7~~!77      ?7!~!7   ^~~~          \r\n        !  :~ :~   !?      J^  .7. :!~!           \r\n       ~:  ^^ ~:   !7      J^  ^!!^7^!.           \r\n       ~^. !~.!:   ?!      7!  .^^~^!^            \r\n        .:^~..!:   J^     .!J   ^7^~~             \r\n              ^!..~J^^::^^::J^..?7^!              \r\n              !7~~!!        7~~!?:!               \r\n^^^^^^^^^^::^!^... 7^^::^^:^! :7:77^::^^^^^^^^^^^^\r\n          .~~^.^:~^!       .!^!~~~^~~.            \r\n          .~:^~^^:.          .!!~~^:~.            \r\n                                                  ");
            Console.WriteLine("\nESSAS SÃO SUAS CARACTERÍSTICAS !\n");
            Console.WriteLine("\nForça Sobre-Humana: Gareth possui uma força física excepcional, capaz de manejar\nsua espada com maestria e derrotar vários inimigos com um único golpe.\n\n\nResistência Inigualável: Sua resistência à dor e fadiga é impressionante, permitindo\nque ele lute por longas horas sem se cansar.\n\n\nAura de Proteção: Gareth emana uma aura mágica que protege seus aliados de ataques\nfísicos e mágicos, tornando-o um escudo impenetrável para seus companheiros.\n\nLiderança Inspiradora: Sua bravura e fé inabaláveis inspiram seus companheiros de\nguilda a lutarem com bravura, mesmo nas situações mais desesperadoras.\n\n\nDomínio da Espada: Gareth é um espadachim talentoso e experiente, capaz de realizar\nmanobras acrobáticas e golpes precisos com sua espada. \n\n");
            Console.WriteLine("\n===============================================================================================================\n");
            Console.WriteLine("SEU PRIMEIRO INIMIGO É A HORDA DE GOBLINS DA BRUXA MORGIANA !\n");
            Console.WriteLine("A horda de goblins da Bruxa Morgiana era um espetáculo caótico e assustador.\nPequenos e curvados, com pele verde-acinzentada e orelhas pontudas, os goblins\ncorriam e gritavam em torno de sua mestra, seus olhos amarelos brilhando com malícia.\n\n");
            Console.WriteLine("  .?~:.    ~!~~~~~^.:::^^~?!          .?~:.    ~!~~~~~^.:::^^~?!          .?~:.    ~!~~~~~^.:::^^~?!    \n   ~J?5J!?5^     ~?7775P?7!.           ~J?5J!?5^     ~?7775P?7!.           ~J?5J!?5^     ~?7775P?7!.    \n     ^YP?G7    .. ^5?JY!                 ^YP?G7    .. ^5?JY!                 ^YP?G7    .. ^5?JY!        \n       ^?Y#Y^ 7J?:J?7^                    ^?Y#Y^ 7J?:J?7^                    ^?Y#Y^ 7J?:J?7^          \n         ^5Y   .^!?^.                      ^5Y   .^!?^.                      ^5Y   .^!?^.           \n        !7.~7~^^.  :^~!:                  !7.~7~^^.  :^~!:                  !7.~7~^^.  :^~!:        \n       :J:!.      ::  .!!.                :J:!.      ::  .!!.                :J:!.      ::  .!!.      \n       .Y ^Y     :!^77: :!~.              .Y ^Y     :!^77: :!~.              .Y ^Y     :!^77: :!~.    \n      :!! ~B.       Y~^?^ .?:            :!! ~B.       Y~^?^ .?:            :!! ~B.       Y~^?^ .?:   \n    ~7~^^!!Y^      7P:  !7:.J          ~7~^^!!Y^      7P:  !7:.J          ~7~^^!!Y^      7P:  !7:.J   \n  ^Y7J7~:. ~5^:....?!Y  ^?7 ~!:       ^Y7J7~:. ~5^:....?!Y  ^?7 ~!:       ^Y7J7~:. ~5^:....?!Y  ^?7 ~!: \n  ^YJP~   7Y~^~!!!!~^?! !7J?!?G:      ^YJP~   7Y~^~!!!!~^?! !7J?!?G:      ^YJP~   7Y~^~!!!!~^?! !7J?!?G:\n   .:.  ~?~^!~   .: 7!J. .J5GY7.        .:.  ~?~^!~   .: 7!J. .J5GY7.        .:.  ~?~^!~   .: 7!J. .J5GY7.\n       ??  :^JJ7YPG5^ ^7                    ??  :^JJ7YPG5^ ^7                    ??  :^JJ7YPG5^ ^7        \n       ^5  !! ^.:~J7?  ~!                   ^5  !! ^.:~J7?  ~!                   ^5  !! ^.:~J7?  ~!       \n        7? ~^       ~J. ~~                   7? ~^       ~J. ~~                   7? ~^       ~J. ~~      \n       .~Y !:        ^7!.!.                 .~Y !:        ^7!.!.                 .~Y !:        ^7!.!.     \n      7P5^^7.          JY~J:               7P5^^7.          JY~J:               7P5^^7.          JY~J:    \n      .^!~:            7?JJ^               .^!~:            7?JJ^               .^!~:            7?JJ^");

            while (gerath.EstáVivo && goblin.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("TURNO DO GERATH:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR ");
                Console.WriteLine("2. CURAR ");
                Console.Write("\nESCOLHA: \n");

                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        gerath.Atacar(goblin);
                        break;
                    case 2:
                        gerath.Curar();
                        break;
                    default:
                        Console.WriteLine("\nESCOLHA INVÁLIDA!");
                        break;
                }

                // Verifica se o inimigo morreu após o ataque do jogador
                if (!goblin.EstáVivo)
                {
                    Console.WriteLine("\nO GOBLIN FOI DERROTADO!");
                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DO GOBLIN:");
                goblin.Atacar(gerath);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!gerath.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELO GOBLIN!");
                    break;
                }

                // Mostra o estado atual dos personagens
                gerath.MostrarEstado();
                goblin.MostrarEstado();
            }

            Console.WriteLine("\n\n\nSEU PRÓXIMO INIMIGO É A BRUXA MORGIANA\n");
            Console.WriteLine("Morgiana, conhecida por sua magia negra e crueldade implacável,\nreúne um exército de goblins ferozes e se alia ao próprio Rei\nDemônio, Azrael, e seu poderoso dragão negro, Incinero.\n\n");
            Console.WriteLine("                    .!.         \r\n                   ~JY          \r\n            .~~:.^5PPJ          \r\n             :~7J5PB&#P^        \r\n               .??~?PPPY:       \r\n               .7YY5#J^^:       \r\n              :7?5Y?Y55Y~       \r\n     .       :Y5JJ7~!JGBB?      \r\n    !?^      ?5J5####&P^JGY.    \r\n    ..?7^::~?PJ~YGB#BB^ .5B~    \r\n      ^P5P5555?PBGBBBP~7PP5!    \r\n      ^?7J?755GB####&5JYJY5!    \r\n      ?~~7?75GB##&&&&#J~?55?.   \r\n     :? .!??PGP5BGPB##P^~7J^.   \r\n     7!   ^!PBPYP??PG##!.!^     \r\n     ~7    :PBG55?5BGB#5 .      \r\n      J.   :B#BPPYGBGBBB:       \r\n      ??   !##BPBGGGGBB#!       \r\n     ~5B7. ?##BPB#GBBBB#J       \r\n     ?BB5. 5##BGB#BBB#B#P       \r\n    .5BBB~ P##BGGBB###B#B:      \r\n     JGGBY^B#BGGBB55G#BB&!      \r\n     ~7?77~Y5P^:PJ  ~G?:?J.     ");
            while (gerath.EstáVivo && morgiana.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("\nTURNO DO GERATH:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1.ATACAR");
                Console.WriteLine("2.CURAR ");
                Console.Write("ESCOLHA: ");

                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        gerath.Atacar(morgiana);
                        break;
                    case 2:
                        gerath.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }


                if (!morgiana.EstáVivo)
                {
                    Console.WriteLine("\nA MORGIANA FOI DERROTADA!");

                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DA MORGIANA:");
                morgiana.Atacar(gerath);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!gerath.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELA MORGIANA!");

                    break;
                }

                // Mostra o estado atual dos personagens
                gerath.MostrarEstado();
                morgiana.MostrarEstado();
            }


            Console.WriteLine("AGORA VOCÊ ESTÁ NO ÚLTIMO INIMIGO: O REI DEMÔNIO!\n\n");
            Console.WriteLine("                                 _\r\n                              ==(W{==========-      /===-\r\n                                ||  (.--.)         /===-_---~~~~~~~----__\r\n                                | \\_,|**|,__      |===-~___            _,-'`\r\n                   -==\\\\        `\\ ' `--'   ),    `//~\\\\   ~~~~`--._.-~\r\n               ______-==|        /`\\_. .__/\\ \\    | |  \\\\          _-~`\r\n         __--~~~  ,-/-==\\\\      (   | .  |~~~~|   | |   `\\       ,'\r\n      _-~       /'    |  \\\\     )__/==0==-\\<>/   / /      \\     /\r\n    .'        /       |   \\\\      /~\\___/~~\\/  /' /        \\   /\r\n   /  ____  /         |    \\`\\.__/-~~   \\  |_/'  /          \\/'\r\n  /-'~    ~~~~~---__  |     ~-/~         ( )   /'        _--~`\r\n                    \\_|      /        _) | ;  ),   __--~~\r\n                      '~~--_/      _-~/- |/ \\   '-~ \\\r\n                     {\\__--_/}    / \\\\_>-|)<__\\      \\\r\n                     /'   (_/  _-~  | |__>--<__|      |\r\n                    |   _/) )-~     | |__>--<__|      |\r\n                    / /~ ,_/       / /__>---<__/      |\r\n                   o-o _//        /-~_>---<__-~      /\r\n                   (^(~          /~_>---<__-      _-~\r\n                  ,/|           /__>--<__/     _-~\r\n               ,//('(          |__>--<__|     /                  .--_\r\n              ( ( '))          |__>--<__|    |                 /' _-_~\\\r\n           `-)) )) (           |__>--<__|    |               /'  /   ~\\`\\\r\n          ,/,'//( (             \\__>--<__\\    \\            /'  //      ||\r\n        ,( ( ((, ))              ~-__>--<_~-_  ~--__---~'/'/  /'       VV\r\n      `~/  )` ) ,/|                 ~-_~>--<_/-__      __-~ _/\r\n    ._-~//( )/ )) `                    ~~-'_/_/ /~~~~~__--~\r\n     ;'( ')/ ,)(                              ~~~~~~~~\r\n    ' ') '( (/");
            while (gerath.EstáVivo && azraelEincinero.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("\nTURNO DO GERATH:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR ");
                Console.WriteLine("2. CURAR ");
                Console.Write("ESCOLHA: ");
                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        gerath.Atacar(azraelEincinero);
                        break;
                    case 2:
                        gerath.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }


                if (!azraelEincinero.EstáVivo)
                {
                    Console.WriteLine("\nO REI DEMÔNIO FOI DERROTADO!");
                    string michael;
                    Console.WriteLine("\nPARABÉNS VOCÊ ZEROU O JOGO, AGORA FIQUE COM ESSA MENSAGEM DO GRANDE SÁBIO MICHAEL.");
                    Console.WriteLine("CLIQUE NO ENTER...");
                    michael = Console.ReadLine();
                    Console.WriteLine("@@@@@@%##%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+---------\r\n@@@@@@%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#*--------\r\n@@@@@@%#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%--------\r\n@@@@@@%%%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+------\r\n#%@@%%###%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+------\r\n.*%@%#%%#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%%%#####***#######%%%@@@@@@@@@%%+-----\r\n--+#%#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%%#**++++==+=--==+++++++*#%%@@@@@@@@@*-----\r\n---=*#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%#*===-----------------=++++++**#%@@@@@@#=----\r\n.---=#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%##*=--------------------------++++++*#%@@@@%*=---\r\n---=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#*+==---------------------------++++++++*#%@@@#=---\r\n---=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%###+=-------------------------------+++++++++*#@@@@@=--\r\n::-=##%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+=----------------------------------=++++++++**@@@@@=--\r\n.-::#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+----------------------------------=++++++++++++*#%@@@*=-\r\n...:#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%*+=-----------------------------------==++++++++++**#%@@@%+-\r\n--+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#*=--------------------------------------==+++++++++++*#%@@@@*-\r\n.-*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#=-----------------------------------------=++++=-=++++*#%@@@%*-\r\n--*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+=---------------------------------------------=+=+++++*#%@@@%*-\r\n-+*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#+=----------=++++++++++++++=----=+++=-----------=+++++++++*#%@@@*-\r\n=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@%%#+=---===+########%%#%%#######*******+++++====+++++++++++++++*#@@%=:\r\n=#@@@@@@@@@@@@@@@@@@@@@@@@@@@%#*==-=+++**###********##%%@@@@%%########*++++++++++++*########**#%@=--\r\n-*%@@@@@@@@@@@@@@@@@@@@@@@@%##+----=++++++++--=+====+++++#############**++++++***###%%@@@@@%%%@@@=--\r\n.*%@@@@@@@@@@@@@@@@@@@@@@@%#+=-----=====-=++++*############*##*********++++++**#####%%%@@@@@@@@%%=--\r\n=*%@@@@@@@@@@@@@@@@@@@@@@@#+-----------=++*##%@@@@@@@@%#*#######++++++==+++++*##############*#%*.---\r\n=#@@@@@@@@@@@@@@@@@@@@@@%#+-----------=+++*##*+++%@@@@#++#######++++----=++++*###%@@@@@%####*%@%=---\r\n=#%@@@@@@@@@@@@@@@@@@@@%#==------------======-==-=+++++++******++++=------=++#%%@@@@%**#@%%#@@+:-:--\r\n=#@@@@@@@@@@@@@@@@@@@@@%+=-------------------------=+++++++++++++=---------=+################:.....:\r\n-=#@@@@@@@@@@@@@@@@@@@%#+----------------------------=++++++++=--------------+*##########**#*:....::\r\n--*@@@@@@@@@@@@@@@@@@@#+-------------------------------=====-----------------++*#*******++**........\r\n--*@@@@@@@@@@@@@@@@@@%#++=----------------------------------------------------=++++++++++#=........:\r\n--+*%@@@@@@@@@@@@@@@%%*++=----------------------------------------------------==+++++++++=:.........\r\n---=%@@@@@@@@@@@%%%%##*++=-----------------------------------------------------=+++++++++=:.........\r\n---=+%@@@@@@@@@%#######*+=-----------------------------------------------------=+++++++++=----------\r\n----=#%@@@@@@@%#####*#**+=------------------------------------------------------=++++++++=----------\r\n---=++#@@@@@@%%###***#*++=-------------------------------------------------------++++++++=----------\r\n------+%@@@@@%%%%%%*+***+=---------------------------------=++=------------------=++++++------------\r\n------+%%@@@@@@@%#%%*#**+=-------------------------------=++++++------------------++++++------------\r\n------=*%@@@@@%%####*##*+==----------------------------==+++==--------------------++++++------------\r\n------=*%@@@@@%###*+*#*++=----------------------------=+++=----------------------+++++++------------\r\n------=*%@@@@%%#+==++***+==--------------------------=+++---------===+++*+===-===+++++++------------\r\n------+#%@@@%%#+=-=*###*++=------------------------=+++=----------==+*###**+++++++++++++---=+=------\n\n\n");
                    Console.WriteLine(" ____ ___ ____ _____ _____ __  __    _                                       \r\n/ ___|_ _/ ___|_   _| ____|  \\/  |  / \\                                      \r\n\\___ \\| |\\___ \\ | | |  _| | |\\/| | / _ \\                                     \r\n ___) | | ___) || | | |___| |  | |/ ___ \\                                    \r\n|____/___|____/ |_|_|_____|_|  |_/_/  _\\_\\   ___                             \r\n| |   |_ _| __ )| ____|  _ \\    / \\  |  _ \\ / _ \\                            \r\n| |    | ||  _ \\|  _| | |_) |  / _ \\ | | | | | | |                           \r\n| |___ | || |_) | |___|  _ <  / ___ \\| |_| | |_| |                           \r\n|_____|___|____/|_____|_| \\_\\/_/__ \\_\\____/_\\___/___  _   _  ____  /\\/| ___  \r\n|  _ \\ / \\  |  _ \\    / \\    |  _ \\|  _ \\ / _ \\|  _ \\| | | |/ ___||/\\/ / _ \\ \r\n| |_) / _ \\ | |_) |  / _ \\   | |_) | |_) | | | | | | | | | | |     /_\\| | | |\r\n|  __/ ___ \\|  _ <  / ___ \\  |  __/|  _ <| |_| | |_| | |_| | |___ / _ \\ |_| |\r\n|_| /_/   \\_\\_| \\_\\/_/   \\_\\ |_|   |_| \\_\\\\___/|____/ \\___/ \\____/_/ \\_\\___/ \r\n    _    _   _____ ___    _____ _____ ___  ____    _____ __  _)_)            \r\n   / \\  | | |_   _/ _ \\  |_   _| ____/ _ \\|  _ \\  | ____|  \\/  |             \r\n  / _ \\ | |   | || | | |   | | |  _|| | | | |_) | |  _| | |\\/| |             \r\n / ___ \\| |___| || |_| |   | | | |__| |_| |  _ <  | |___| |  | |             \r\n/_/___\\_\\_____|_| \\___/___ |_| |_____\\___/|_|_\\_\\ |_____|_|  |_|             \r\n / ___|  / \\  |  \\/  | __ )_ _|  / \\  |  _ \\|  _ \\    / \\                    \r\n| |  _  / _ \\ | |\\/| |  _ \\| |  / _ \\ | |_) | |_) |  / _ \\                   \r\n| |_| |/ ___ \\| |  | | |_) | | / ___ \\|  _ <|  _ <  / ___ \\                  \r\n \\____/_/   \\_\\_|  |_|____/___/_/   \\_\\_| \\_\\_| \\_\\/_/   \\_\\                 ");

                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DO AZRAEL:");
                azraelEincinero.Atacar(gerath);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!gerath.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELO REI DEMÔNIO!\n");
                    Console.WriteLine("                 mo / )\r\n                 |/)\\)\r\n                  /\\_\r\n                  \\__|=\r\n                 (    )\r\n                 __)(__\r\n           _____/      \\\\_____\r\n          |  _     ___   _   ||\r\n          | | \\     |   | \\  ||\r\n          | |  |    |   |  | ||\r\n          | |_/     |   |_/  ||\r\n          | | \\     |   |    ||\r\n          | |  \\    |   |    ||\r\n          | |   \\. _|_. | .  ||\r\n          |                  ||\r\n          |      GERATH      ||\r\n          |                  ||\r\n  *       | *   **    * **   |**      **\r\n   \\))ejm97/.,(//,,..,,\\||(,,.,\\\\,.((//");
                    break;
                }

                // Mostra o estado atual dos personagens
                gerath.MostrarEstado();
                azraelEincinero.MostrarEstado();
            }
        }
        else if (escolha == 2)
        {
            Console.WriteLine("VOCÊ ESCOLHEU O MAGO ELDRIN !\n");
            Console.WriteLine("                  ^?55Y7:       \r\n               .~75P55PG57      \r\n            .^7JJY555PGBP5J^    \r\n           ^?J?J??YP5PGGPGGPJ7?~\r\n         ^J5555PPPPPPGGG7^~!?7~.\r\n       ^?555PPPPPPPPPPGG5       \r\n     ^?5PPPY?7777?Y5PPGGG:      \r\n    ~PPPP?!!7::^7?~~755GG5!  :. \r\n    .?PPG?~77^:~??^~^!?GBBB!JYYJ\r\n      :7J?^^~~^^:^^^:JBGPY!?5555\r\n:^::     ^^^~??!:^^:~~^:. .5?:^.\r\n!!~~::.:?5J^:::..^^~JY:  .:?!.  \r\n:::^^!5PGGJ^::::::~5PPPJY!^J7^  \r\n    7?PGPP7^...^~7!555PPJ!~J5.  \r\n    5#BGP5J:..^?YPG55P5PGP.J5.  \r\n   :B#5Y5PJ!:75PPPG5.?PB#J YJ   \r\n   .?J:^PPP5?5P55PPP. :?P!!5^   \r\n       ~P5PPPPP5PPGG.    .5?    \r\n       ?PPP55PPPPPPG~    :5~    \r\n      :5GPPP5PPPPP5GY    .Y!    \r\n      7PPPPP5PPP5PP5G~    !J    \r\n    .7PGP5PPPPPP55PPPG!   ~J    \r\n    ~5BBGGGB?7?YGPPGGPG?  ^^    \r\n     :JYYJJ?.  .JGBG~::.   \n");
            Console.WriteLine("\nESSAS SÃO SUAS CARACTERÍSTICAS !\n");
            Console.WriteLine("\nSabedoria Mística: Eldrin possui um vasto conhecimento de magia arcana,\ncapaz de conjurar feitiços poderosos e desvendar segredos místicos há muito perdidos.\n\n\nForça Mágica Imensurável: Sua força mágica é quase ilimitada, permitindo\nque ele conjure feitiços de grande escala com efeitos devastadores.\n\n\nTeletransporte: Eldrin pode se teletransportar para qualquer lugar\ninstantaneamente, tornando-o um aliado inestimável em missões de resgate ou reconhecimento.\n\n\nVisão do Futuro: Através de sua magia, Eldrin pode ter visões do futuro,\nprevendo eventos e ajudando seus aliados a tomar decisões estratégicas.\n\n\nManipulação dos Elementos: Eldrin tem controle sobre os elementos da natureza,\ncomo fogo, água, terra e ar, podendo usá-los para atacar seus inimigos ou proteger seus aliados.\n\n");
            Console.WriteLine("========================================================================\n");
            Console.WriteLine("SEU PRIMEIRO INIMIGO É A HORDA DE GOBLINS DA BRUXA MORGIANA !\n");
            Console.WriteLine("A horda de goblins da Bruxa Morgiana era um espetáculo caótico e assustador.\nPequenos e curvados, com pele verde-acinzentada e orelhas pontudas, os goblins\ncorriam e gritavam em torno de sua mestra, seus olhos amarelos brilhando com malícia.\n");
            Console.WriteLine("  .?~:.    ~!~~~~~^.:::^^~?!          .?~:.    ~!~~~~~^.:::^^~?!          .?~:.    ~!~~~~~^.:::^^~?!    \n   ~J?5J!?5^     ~?7775P?7!.           ~J?5J!?5^     ~?7775P?7!.           ~J?5J!?5^     ~?7775P?7!.    \n     ^YP?G7    .. ^5?JY!                 ^YP?G7    .. ^5?JY!                 ^YP?G7    .. ^5?JY!        \n       ^?Y#Y^ 7J?:J?7^                    ^?Y#Y^ 7J?:J?7^                    ^?Y#Y^ 7J?:J?7^          \n         ^5Y   .^!?^.                      ^5Y   .^!?^.                      ^5Y   .^!?^.           \n        !7.~7~^^.  :^~!:                  !7.~7~^^.  :^~!:                  !7.~7~^^.  :^~!:        \n       :J:!.      ::  .!!.                :J:!.      ::  .!!.                :J:!.      ::  .!!.      \n       .Y ^Y     :!^77: :!~.              .Y ^Y     :!^77: :!~.              .Y ^Y     :!^77: :!~.    \n      :!! ~B.       Y~^?^ .?:            :!! ~B.       Y~^?^ .?:            :!! ~B.       Y~^?^ .?:   \n    ~7~^^!!Y^      7P:  !7:.J          ~7~^^!!Y^      7P:  !7:.J          ~7~^^!!Y^      7P:  !7:.J   \n  ^Y7J7~:. ~5^:....?!Y  ^?7 ~!:       ^Y7J7~:. ~5^:....?!Y  ^?7 ~!:       ^Y7J7~:. ~5^:....?!Y  ^?7 ~!: \n  ^YJP~   7Y~^~!!!!~^?! !7J?!?G:      ^YJP~   7Y~^~!!!!~^?! !7J?!?G:      ^YJP~   7Y~^~!!!!~^?! !7J?!?G:\n   .:.  ~?~^!~   .: 7!J. .J5GY7.        .:.  ~?~^!~   .: 7!J. .J5GY7.        .:.  ~?~^!~   .: 7!J. .J5GY7.\n       ??  :^JJ7YPG5^ ^7                    ??  :^JJ7YPG5^ ^7                    ??  :^JJ7YPG5^ ^7        \n       ^5  !! ^.:~J7?  ~!                   ^5  !! ^.:~J7?  ~!                   ^5  !! ^.:~J7?  ~!       \n        7? ~^       ~J. ~~                   7? ~^       ~J. ~~                   7? ~^       ~J. ~~      \n       .~Y !:        ^7!.!.                 .~Y !:        ^7!.!.                 .~Y !:        ^7!.!.     \n      7P5^^7.          JY~J:               7P5^^7.          JY~J:               7P5^^7.          JY~J:    \n      .^!~:            7?JJ^               .^!~:            7?JJ^               .^!~:            7?JJ^");


            while (eldrin.EstáVivo && goblin.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("\nTURNO DO ELDRIN:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR ");
                Console.WriteLine("2. CURAR ");
                Console.Write("ESCOLHA: ");
                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        eldrin.Atacar(goblin);
                        break;
                    case 2:
                        eldrin.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }

                // Verifica se o inimigo morreu após o ataque do jogador
                if (!goblin.EstáVivo)
                {
                    Console.WriteLine("\n\nO GOBLIN FOI DERROTADO!");
                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DO GOBLIN:");
                goblin.Atacar(eldrin);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!eldrin.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELO GOBLIN!");
                    break;
                }

                // Mostra o estado atual dos personagens
                eldrin.MostrarEstado();
                goblin.MostrarEstado();
            }

            Console.WriteLine("\n\n\nSEU PRÓXIMO INIMIGO É A BRUXA MORGIANA\n");
            Console.WriteLine("Morgiana, conhecida por sua magia negra e crueldade implacável,\nreúne um exército de goblins ferozes e se alia ao próprio Rei\nDemônio, Azrael, e seu poderoso dragão negro, Incinero.\n\n");
            Console.WriteLine("                    .!.         \r\n                   ~JY          \r\n            .~~:.^5PPJ          \r\n             :~7J5PB&#P^        \r\n               .??~?PPPY:       \r\n               .7YY5#J^^:       \r\n              :7?5Y?Y55Y~       \r\n     .       :Y5JJ7~!JGBB?      \r\n    !?^      ?5J5####&P^JGY.    \r\n    ..?7^::~?PJ~YGB#BB^ .5B~    \r\n      ^P5P5555?PBGBBBP~7PP5!    \r\n      ^?7J?755GB####&5JYJY5!    \r\n      ?~~7?75GB##&&&&#J~?55?.   \r\n     :? .!??PGP5BGPB##P^~7J^.   \r\n     7!   ^!PBPYP??PG##!.!^     \r\n     ~7    :PBG55?5BGB#5 .      \r\n      J.   :B#BPPYGBGBBB:       \r\n      ??   !##BPBGGGGBB#!       \r\n     ~5B7. ?##BPB#GBBBB#J       \r\n     ?BB5. 5##BGB#BBB#B#P       \r\n    .5BBB~ P##BGGBB###B#B:      \r\n     JGGBY^B#BGGBB55G#BB&!      \r\n     ~7?77~Y5P^:PJ  ~G?:?J.     ");

            while (eldrin.EstáVivo && morgiana.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("\nTURNO DO ELDRIN:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR ");
                Console.WriteLine("2. CURAR ");
                Console.Write("ESCOLHA: ");
                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        eldrin.Atacar(morgiana);
                        break;
                    case 2:
                        eldrin.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }


                if (!morgiana.EstáVivo)
                {
                    Console.WriteLine("\nA MORGIANA FOI DERROTADA!");
                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DA MORGIANA:");
                morgiana.Atacar(eldrin);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!eldrin.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELA MORGIANA!");
                    break;
                }

                // Mostra o estado atual dos personagens
                eldrin.MostrarEstado();
                morgiana.MostrarEstado();
            }


            Console.WriteLine("AGORA VOCÊ ESTÁ NO ÚLTIMO INIMIGO: O REI DEMÔNIO!\n\n");
            Console.WriteLine("                                 _\r\n                              ==(W{==========-      /===-\r\n                                ||  (.--.)         /===-_---~~~~~~~----__\r\n                                | \\_,|**|,__      |===-~___            _,-'`\r\n                   -==\\\\        `\\ ' `--'   ),    `//~\\\\   ~~~~`--._.-~\r\n               ______-==|        /`\\_. .__/\\ \\    | |  \\\\          _-~`\r\n         __--~~~  ,-/-==\\\\      (   | .  |~~~~|   | |   `\\       ,'\r\n      _-~       /'    |  \\\\     )__/==0==-\\<>/   / /      \\     /\r\n    .'        /       |   \\\\      /~\\___/~~\\/  /' /        \\   /\r\n   /  ____  /         |    \\`\\.__/-~~   \\  |_/'  /          \\/'\r\n  /-'~    ~~~~~---__  |     ~-/~         ( )   /'        _--~`\r\n                    \\_|      /        _) | ;  ),   __--~~\r\n                      '~~--_/      _-~/- |/ \\   '-~ \\\r\n                     {\\__--_/}    / \\\\_>-|)<__\\      \\\r\n                     /'   (_/  _-~  | |__>--<__|      |\r\n                    |   _/) )-~     | |__>--<__|      |\r\n                    / /~ ,_/       / /__>---<__/      |\r\n                   o-o _//        /-~_>---<__-~      /\r\n                   (^(~          /~_>---<__-      _-~\r\n                  ,/|           /__>--<__/     _-~\r\n               ,//('(          |__>--<__|     /                  .--_\r\n              ( ( '))          |__>--<__|    |                 /' _-_~\\\r\n           `-)) )) (           |__>--<__|    |               /'  /   ~\\`\\\r\n          ,/,'//( (             \\__>--<__\\    \\            /'  //      ||\r\n        ,( ( ((, ))              ~-__>--<_~-_  ~--__---~'/'/  /'       VV\r\n      `~/  )` ) ,/|                 ~-_~>--<_/-__      __-~ _/\r\n    ._-~//( )/ )) `                    ~~-'_/_/ /~~~~~__--~\r\n     ;'( ')/ ,)(                              ~~~~~~~~\r\n    ' ') '( (/");

            while (eldrin.EstáVivo && azraelEincinero.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("\nTURNO DO ELDRIN:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR");
                Console.WriteLine("2. CURAR");
                Console.Write("ESCOLHA: ");
                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        eldrin.Atacar(azraelEincinero);
                        break;
                    case 2:
                        eldrin.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }


                if (!azraelEincinero.EstáVivo)
                {
                    Console.WriteLine("O REI DEMÔNIO FOI DERROTADO!");
                    string michael;
                    Console.WriteLine("\nPARABÉNS VOCÊ ZEROU O JOGO, AGORA FIQUE COM ESSA MENSAGEM DO GRANDE SÁBIO MICHAEL.");
                    Console.WriteLine("CLIQUE NO ENTER...");
                    michael = Console.ReadLine();
                    Console.WriteLine("@@@@@@%##%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+---------\r\n@@@@@@%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#*--------\r\n@@@@@@%#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%--------\r\n@@@@@@%%%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+------\r\n#%@@%%###%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+------\r\n.*%@%#%%#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%%%#####***#######%%%@@@@@@@@@%%+-----\r\n--+#%#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%%#**++++==+=--==+++++++*#%%@@@@@@@@@*-----\r\n---=*#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%#*===-----------------=++++++**#%@@@@@@#=----\r\n.---=#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%##*=--------------------------++++++*#%@@@@%*=---\r\n---=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#*+==---------------------------++++++++*#%@@@#=---\r\n---=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%###+=-------------------------------+++++++++*#@@@@@=--\r\n::-=##%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+=----------------------------------=++++++++**@@@@@=--\r\n.-::#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+----------------------------------=++++++++++++*#%@@@*=-\r\n...:#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%*+=-----------------------------------==++++++++++**#%@@@%+-\r\n--+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#*=--------------------------------------==+++++++++++*#%@@@@*-\r\n.-*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#=-----------------------------------------=++++=-=++++*#%@@@%*-\r\n--*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+=---------------------------------------------=+=+++++*#%@@@%*-\r\n-+*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#+=----------=++++++++++++++=----=+++=-----------=+++++++++*#%@@@*-\r\n=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@%%#+=---===+########%%#%%#######*******+++++====+++++++++++++++*#@@%=:\r\n=#@@@@@@@@@@@@@@@@@@@@@@@@@@@%#*==-=+++**###********##%%@@@@%%########*++++++++++++*########**#%@=--\r\n-*%@@@@@@@@@@@@@@@@@@@@@@@@%##+----=++++++++--=+====+++++#############**++++++***###%%@@@@@%%%@@@=--\r\n.*%@@@@@@@@@@@@@@@@@@@@@@@%#+=-----=====-=++++*############*##*********++++++**#####%%%@@@@@@@@%%=--\r\n=*%@@@@@@@@@@@@@@@@@@@@@@@#+-----------=++*##%@@@@@@@@%#*#######++++++==+++++*##############*#%*.---\r\n=#@@@@@@@@@@@@@@@@@@@@@@%#+-----------=+++*##*+++%@@@@#++#######++++----=++++*###%@@@@@%####*%@%=---\r\n=#%@@@@@@@@@@@@@@@@@@@@%#==------------======-==-=+++++++******++++=------=++#%%@@@@%**#@%%#@@+:-:--\r\n=#@@@@@@@@@@@@@@@@@@@@@%+=-------------------------=+++++++++++++=---------=+################:.....:\r\n-=#@@@@@@@@@@@@@@@@@@@%#+----------------------------=++++++++=--------------+*##########**#*:....::\r\n--*@@@@@@@@@@@@@@@@@@@#+-------------------------------=====-----------------++*#*******++**........\r\n--*@@@@@@@@@@@@@@@@@@%#++=----------------------------------------------------=++++++++++#=........:\r\n--+*%@@@@@@@@@@@@@@@%%*++=----------------------------------------------------==+++++++++=:.........\r\n---=%@@@@@@@@@@@%%%%##*++=-----------------------------------------------------=+++++++++=:.........\r\n---=+%@@@@@@@@@%#######*+=-----------------------------------------------------=+++++++++=----------\r\n----=#%@@@@@@@%#####*#**+=------------------------------------------------------=++++++++=----------\r\n---=++#@@@@@@%%###***#*++=-------------------------------------------------------++++++++=----------\r\n------+%@@@@@%%%%%%*+***+=---------------------------------=++=------------------=++++++------------\r\n------+%%@@@@@@@%#%%*#**+=-------------------------------=++++++------------------++++++------------\r\n------=*%@@@@@%%####*##*+==----------------------------==+++==--------------------++++++------------\r\n------=*%@@@@@%###*+*#*++=----------------------------=+++=----------------------+++++++------------\r\n------=*%@@@@%%#+==++***+==--------------------------=+++---------===+++*+===-===+++++++------------\r\n------+#%@@@%%#+=-=*###*++=------------------------=+++=----------==+*###**+++++++++++++---=+=------\n\n\n");
                    Console.WriteLine(" ____ ___ ____ _____ _____ __  __    _                                       \r\n/ ___|_ _/ ___|_   _| ____|  \\/  |  / \\                                      \r\n\\___ \\| |\\___ \\ | | |  _| | |\\/| | / _ \\                                     \r\n ___) | | ___) || | | |___| |  | |/ ___ \\                                    \r\n|____/___|____/ |_|_|_____|_|  |_/_/  _\\_\\   ___                             \r\n| |   |_ _| __ )| ____|  _ \\    / \\  |  _ \\ / _ \\                            \r\n| |    | ||  _ \\|  _| | |_) |  / _ \\ | | | | | | |                           \r\n| |___ | || |_) | |___|  _ <  / ___ \\| |_| | |_| |                           \r\n|_____|___|____/|_____|_| \\_\\/_/__ \\_\\____/_\\___/___  _   _  ____  /\\/| ___  \r\n|  _ \\ / \\  |  _ \\    / \\    |  _ \\|  _ \\ / _ \\|  _ \\| | | |/ ___||/\\/ / _ \\ \r\n| |_) / _ \\ | |_) |  / _ \\   | |_) | |_) | | | | | | | | | | |     /_\\| | | |\r\n|  __/ ___ \\|  _ <  / ___ \\  |  __/|  _ <| |_| | |_| | |_| | |___ / _ \\ |_| |\r\n|_| /_/   \\_\\_| \\_\\/_/   \\_\\ |_|   |_| \\_\\\\___/|____/ \\___/ \\____/_/ \\_\\___/ \r\n    _    _   _____ ___    _____ _____ ___  ____    _____ __  _)_)            \r\n   / \\  | | |_   _/ _ \\  |_   _| ____/ _ \\|  _ \\  | ____|  \\/  |             \r\n  / _ \\ | |   | || | | |   | | |  _|| | | | |_) | |  _| | |\\/| |             \r\n / ___ \\| |___| || |_| |   | | | |__| |_| |  _ <  | |___| |  | |             \r\n/_/___\\_\\_____|_| \\___/___ |_| |_____\\___/|_|_\\_\\ |_____|_|  |_|             \r\n / ___|  / \\  |  \\/  | __ )_ _|  / \\  |  _ \\|  _ \\    / \\                    \r\n| |  _  / _ \\ | |\\/| |  _ \\| |  / _ \\ | |_) | |_) |  / _ \\                   \r\n| |_| |/ ___ \\| |  | | |_) | | / ___ \\|  _ <|  _ <  / ___ \\                  \r\n \\____/_/   \\_\\_|  |_|____/___/_/   \\_\\_| \\_\\_| \\_\\/_/   \\_\\                 ");

                    break;
                }
                // Turno do inimigo
                Console.WriteLine("\nTURNO DO AZRAEL:");
                azraelEincinero.Atacar(eldrin);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!eldrin.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELO REI DEMÔNIO!\n");
                    Console.WriteLine("                 mo / )\r\n                 |/)\\)\r\n                  /\\_\r\n                  \\__|=\r\n                 (    )\r\n                 __)(__\r\n           _____/      \\\\_____\r\n          |  _     ___   _   ||\r\n          | | \\     |   | \\  ||\r\n          | |  |    |   |  | ||\r\n          | |_/     |   |_/  ||\r\n          | | \\     |   |    ||\r\n          | |  \\    |   |    ||\r\n          | |   \\. _|_. | .  ||\r\n          |                  ||\r\n          |       ELDRIN     ||\r\n          |                  ||\r\n  *       | *   **    * **   |**      **\r\n   \\))ejm97/.,(//,,..,,\\||(,,.,\\\\,.((//");
                    break;
                }

                // Mostra o estado atual dos personagens
                eldrin.MostrarEstado();
                azraelEincinero.MostrarEstado();
            }
        }
        else if (escolha == 3)
        {
            Console.WriteLine("VOCÊ ESCOLHEU O ARQUEIRO OLIVER !\n");
            Console.WriteLine("                       :^      \r\n                     ... ^~     \r\n                  ...     ^~.   \r\n         :~^:.:^:.         :7:  \r\n        ~J^!!7~P^          :^^  \r\n    ..::?!YY!JP?...       ^~^.  \r\n ~???!J?7~557!^JJ~~~~!!7??5J~~~ \r\n.?Y5G#5?JJ7^:7PGJ:^PJY??P?Y^    \r\n   :7JBG?~...?PJ!^::::^!!~      \r\n      J@@5J~.~!^       ^^:      \r\n       JBJJ7~~!.     .^^:       \r\n        !PJP7~^!^  :^^.         \r\n       .7!?JY~:.^!~^.           \r\n      ~7..^GGY?::^^^            \r\n     7B!  7P^ ~YPJ7!!.          \r\n    .PBP7?7~!.  ^J55P7~~.       \r\n     !J5P#J^!      !P?J:7^      \r\n      .::~J!^       ?&&J^~      \r\n           .         ^~?57^     \r\n                        :Y7!:   \r\n                         :J7:   ");
            Console.WriteLine("\nESSAS SÃO SUAS CARACTERÍSTICAS !\n");
            Console.WriteLine("Precisão Mortal: Oliver possui uma mira impecável, capaz de acertar\nalvos com precisão milimétrica, mesmo a longas distâncias.\n\n\nFlechas Mágicas: Ele tem acesso a uma variedade de flechas mágicas,\ncada uma com efeitos únicos, como flechas que curam aliados, flechas\nque explodem em chamas ou flechas que congelam seus inimigos.\n\n\nTiro Múltiplo: Oliver pode disparar várias flechas em rápida sucessão,\ncriando uma chuva de projéteis que podem devastar seus oponentes.\n\n\nFlechas Rastreadoras: Ele pode imbuir suas flechas com magia para que\nelas sigam seus alvos, mesmo que estejam escondidos ou em movimento.\n\n\nVisão Noturna: Oliver tem uma visão noturna aprimorada, permitindo\nque ele visualize seus inimigos mesmo na escuridão total.\n\n");
            Console.WriteLine("\n===============================================================================================================\n");
            Console.WriteLine("\nSEU PRIMEIRO INIMIGO É A HORDA DE GOBLINS DA BRUXA MORGIANA !\n");
            Console.WriteLine("A horda de goblins da Bruxa Morgiana era um espetáculo caótico e assustador. Pequenos e curvados, com pele verde-acinzentada e orelhas pontudas, os goblins corriam e gritavam em torno de sua mestra, seus olhos amarelos brilhando com malícia.");
            Console.WriteLine("  .?~:.    ~!~~~~~^.:::^^~?!          .?~:.    ~!~~~~~^.:::^^~?!          .?~:.    ~!~~~~~^.:::^^~?!    \n   ~J?5J!?5^     ~?7775P?7!.           ~J?5J!?5^     ~?7775P?7!.           ~J?5J!?5^     ~?7775P?7!.    \n     ^YP?G7    .. ^5?JY!                 ^YP?G7    .. ^5?JY!                 ^YP?G7    .. ^5?JY!        \n       ^?Y#Y^ 7J?:J?7^                    ^?Y#Y^ 7J?:J?7^                    ^?Y#Y^ 7J?:J?7^          \n         ^5Y   .^!?^.                      ^5Y   .^!?^.                      ^5Y   .^!?^.           \n        !7.~7~^^.  :^~!:                  !7.~7~^^.  :^~!:                  !7.~7~^^.  :^~!:        \n       :J:!.      ::  .!!.                :J:!.      ::  .!!.                :J:!.      ::  .!!.      \n       .Y ^Y     :!^77: :!~.              .Y ^Y     :!^77: :!~.              .Y ^Y     :!^77: :!~.    \n      :!! ~B.       Y~^?^ .?:            :!! ~B.       Y~^?^ .?:            :!! ~B.       Y~^?^ .?:   \n    ~7~^^!!Y^      7P:  !7:.J          ~7~^^!!Y^      7P:  !7:.J          ~7~^^!!Y^      7P:  !7:.J   \n  ^Y7J7~:. ~5^:....?!Y  ^?7 ~!:       ^Y7J7~:. ~5^:....?!Y  ^?7 ~!:       ^Y7J7~:. ~5^:....?!Y  ^?7 ~!: \n  ^YJP~   7Y~^~!!!!~^?! !7J?!?G:      ^YJP~   7Y~^~!!!!~^?! !7J?!?G:      ^YJP~   7Y~^~!!!!~^?! !7J?!?G:\n   .:.  ~?~^!~   .: 7!J. .J5GY7.        .:.  ~?~^!~   .: 7!J. .J5GY7.        .:.  ~?~^!~   .: 7!J. .J5GY7.\n       ??  :^JJ7YPG5^ ^7                    ??  :^JJ7YPG5^ ^7                    ??  :^JJ7YPG5^ ^7        \n       ^5  !! ^.:~J7?  ~!                   ^5  !! ^.:~J7?  ~!                   ^5  !! ^.:~J7?  ~!       \n        7? ~^       ~J. ~~                   7? ~^       ~J. ~~                   7? ~^       ~J. ~~      \n       .~Y !:        ^7!.!.                 .~Y !:        ^7!.!.                 .~Y !:        ^7!.!.     \n      7P5^^7.          JY~J:               7P5^^7.          JY~J:               7P5^^7.          JY~J:    \n      .^!~:            7?JJ^               .^!~:            7?JJ^               .^!~:            7?JJ^");
            Console.WriteLine("\nAGORA, ESCOLHA UMA AÇÃO!\n");

            while (oliver.EstáVivo && goblin.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\nTURNO DO OLIVER:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR ");
                Console.WriteLine("2. CURAR ");
                Console.Write("ESCOLHA: ");
                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        oliver.Atacar(goblin);
                        break;
                    case 2:
                        oliver.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }

                // Verifica se o inimigo morreu após o ataque do jogador
                if (!goblin.EstáVivo)
                {
                    Console.WriteLine("\nO GOBLIN FOI DERROTADO!");
                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DO GOBLIN:");
                goblin.Atacar(oliver);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!oliver.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELO GOBLIN!");
                    break;
                }
                // Mostra o estado atual dos personagens
                oliver.MostrarEstado();
                goblin.MostrarEstado();
            }

            Console.WriteLine("\n\n\nSEU PRÓXIMO INIMIGO É A BRUXA MORGIANA\n");
            Console.WriteLine("Morgiana, conhecida por sua magia negra e crueldade implacável,\nreúne um exército de goblins ferozes e se alia ao próprio Rei\nDemônio, Azrael, e seu poderoso dragão negro, Incinero.\n\n");
            Console.WriteLine("                    .!.         \r\n                   ~JY          \r\n            .~~:.^5PPJ          \r\n             :~7J5PB&#P^        \r\n               .??~?PPPY:       \r\n               .7YY5#J^^:       \r\n              :7?5Y?Y55Y~       \r\n     .       :Y5JJ7~!JGBB?      \r\n    !?^      ?5J5####&P^JGY.    \r\n    ..?7^::~?PJ~YGB#BB^ .5B~    \r\n      ^P5P5555?PBGBBBP~7PP5!    \r\n      ^?7J?755GB####&5JYJY5!    \r\n      ?~~7?75GB##&&&&#J~?55?.   \r\n     :? .!??PGP5BGPB##P^~7J^.   \r\n     7!   ^!PBPYP??PG##!.!^     \r\n     ~7    :PBG55?5BGB#5 .      \r\n      J.   :B#BPPYGBGBBB:       \r\n      ??   !##BPBGGGGBB#!       \r\n     ~5B7. ?##BPB#GBBBB#J       \r\n     ?BB5. 5##BGB#BBB#B#P       \r\n    .5BBB~ P##BGGBB###B#B:      \r\n     JGGBY^B#BGGBB55G#BB&!      \r\n     ~7?77~Y5P^:PJ  ~G?:?J.     ");
            while (oliver.EstáVivo && morgiana.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("\nTURNO DO OLIVER:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR");
                Console.WriteLine("2. CURAR");
                Console.Write("ESCOLHA: ");

                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        oliver.Atacar(morgiana);
                        break;
                    case 2:
                        oliver.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }

                if (!morgiana.EstáVivo)
                {
                    Console.WriteLine("\nA MORGIANA FOI DERROTADA!");
                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DA MORGIANA:");
                morgiana.Atacar(oliver);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!oliver.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELA MORGIANA!");
                    break;
                }
                // Mostra o estado atual dos personagens
                oliver.MostrarEstado();
                morgiana.MostrarEstado();
            }


            Console.WriteLine("AGORA VOCÊ ESTÁ NO ÚLTIMO INIMIGO: O REI DEMÔNIO!\n\n");
            Console.WriteLine("                                 _\r\n                              ==(W{==========-      /===-\r\n                                ||  (.--.)         /===-_---~~~~~~~----__\r\n                                | \\_,|**|,__      |===-~___            _,-'`\r\n                   -==\\\\        `\\ ' `--'   ),    `//~\\\\   ~~~~`--._.-~\r\n               ______-==|        /`\\_. .__/\\ \\    | |  \\\\          _-~`\r\n         __--~~~  ,-/-==\\\\      (   | .  |~~~~|   | |   `\\       ,'\r\n      _-~       /'    |  \\\\     )__/==0==-\\<>/   / /      \\     /\r\n    .'        /       |   \\\\      /~\\___/~~\\/  /' /        \\   /\r\n   /  ____  /         |    \\`\\.__/-~~   \\  |_/'  /          \\/'\r\n  /-'~    ~~~~~---__  |     ~-/~         ( )   /'        _--~`\r\n                    \\_|      /        _) | ;  ),   __--~~\r\n                      '~~--_/      _-~/- |/ \\   '-~ \\\r\n                     {\\__--_/}    / \\\\_>-|)<__\\      \\\r\n                     /'   (_/  _-~  | |__>--<__|      |\r\n                    |   _/) )-~     | |__>--<__|      |\r\n                    / /~ ,_/       / /__>---<__/      |\r\n                   o-o _//        /-~_>---<__-~      /\r\n                   (^(~          /~_>---<__-      _-~\r\n                  ,/|           /__>--<__/     _-~\r\n               ,//('(          |__>--<__|     /                  .--_\r\n              ( ( '))          |__>--<__|    |                 /' _-_~\\\r\n           `-)) )) (           |__>--<__|    |           /'  /   ~\\`\\\r\n          ,/,'//( (             \\__>--<__\\    \\            /'  //      ||\r\n        ,( ( ((, ))              ~-__>--<_~-_  ~--__---~'/'/  /'       VV\r\n      `~/  )` ) ,/|                 ~-_~>--<_/-__      __-~ _/\r\n    ._-~//( )/ )) `                    ~~-'_/_/ /~~~~~__--~\r\n     ;'( ')/ ,)(                              ~~~~~~~~\r\n    ' ') '( (/");
            while (oliver.EstáVivo && azraelEincinero.EstáVivo)
            {
                // Turno do jogador
                Console.WriteLine("\n===============================================================================================================\n");
                Console.WriteLine("\nTURNO DO OLIVER:");
                Console.WriteLine("ESCOLHA SUA AÇÃO:");
                Console.WriteLine("1. ATACAR ");
                Console.WriteLine("2. CURAR ");
                Console.Write("ESCOLHA: ");

                int escolhaa = Convert.ToInt32(Console.ReadLine());

                switch (escolhaa)
                {
                    case 1:
                        oliver.Atacar(azraelEincinero);
                        break;
                    case 2:
                        oliver.Curar();
                        break;
                    default:
                        Console.WriteLine("ESCOLHA INVÁLIDA!");
                        break;
                }

                if (!azraelEincinero.EstáVivo)
                {
                    Console.WriteLine("\nO REI DEMÔNIO FOI DERROTADO!");
                    string michael;
                    Console.WriteLine("\nPARABÉNS VOCÊ ZEROU O JOGO, AGORA FIQUE COM ESSA MENSAGEM DO GRANDE SÁBIO MICHAEL.");
                    Console.WriteLine("CLIQUE NO ENTER...");
                    michael = Console.ReadLine();
                    Console.WriteLine("@@@@@@%##%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+---------\r\n@@@@@@%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#*--------\r\n@@@@@@%#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%--------\r\n@@@@@@%%%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+------\r\n#%@@%%###%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+------\r\n.*%@%#%%#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%%%#####***#######%%%@@@@@@@@@%%+-----\r\n--+#%#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%%#**++++==+=--==+++++++*#%%@@@@@@@@@*-----\r\n---=*#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%#*===-----------------=++++++**#%@@@@@@#=----\r\n.---=#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%##*=--------------------------++++++*#%@@@@%*=---\r\n---=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#*+==---------------------------++++++++*#%@@@#=---\r\n---=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%###+=-------------------------------+++++++++*#@@@@@=--\r\n::-=##%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+=----------------------------------=++++++++**@@@@@=--\r\n.-::#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+----------------------------------=++++++++++++*#%@@@*=-\r\n...:#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%%*+=-----------------------------------==++++++++++**#%@@@%+-\r\n--+#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#*=--------------------------------------==+++++++++++*#%@@@@*-\r\n.-*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#=-----------------------------------------=++++=-=++++*#%@@@%*-\r\n--*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%*+=---------------------------------------------=+=+++++*#%@@@%*-\r\n-+*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#+=----------=++++++++++++++=----=+++=-----------=+++++++++*#%@@@*-\r\n=+#%@@@@@@@@@@@@@@@@@@@@@@@@@@%%#+=---===+########%%#%%#######*******+++++====+++++++++++++++*#@@%=:\r\n=#@@@@@@@@@@@@@@@@@@@@@@@@@@@%#*==-=+++**###********##%%@@@@%%########*++++++++++++*########**#%@=--\r\n-*%@@@@@@@@@@@@@@@@@@@@@@@@%##+----=++++++++--=+====+++++#############**++++++***###%%@@@@@%%%@@@=--\r\n.*%@@@@@@@@@@@@@@@@@@@@@@@%#+=-----=====-=++++*############*##*********++++++**#####%%%@@@@@@@@%%=--\r\n=*%@@@@@@@@@@@@@@@@@@@@@@@#+-----------=++*##%@@@@@@@@%#*#######++++++==+++++*##############*#%*.---\r\n=#@@@@@@@@@@@@@@@@@@@@@@%#+-----------=+++*##*+++%@@@@#++#######++++----=++++*###%@@@@@%####*%@%=---\r\n=#%@@@@@@@@@@@@@@@@@@@@%#==------------======-==-=+++++++******++++=------=++#%%@@@@%**#@%%#@@+:-:--\r\n=#@@@@@@@@@@@@@@@@@@@@@%+=-------------------------=+++++++++++++=---------=+################:.....:\r\n-=#@@@@@@@@@@@@@@@@@@@%#+----------------------------=++++++++=--------------+*##########**#*:....::\r\n--*@@@@@@@@@@@@@@@@@@@#+-------------------------------=====-----------------++*#*******++**........\r\n--*@@@@@@@@@@@@@@@@@@%#++=----------------------------------------------------=++++++++++#=........:\r\n--+*%@@@@@@@@@@@@@@@%%*++=----------------------------------------------------==+++++++++=:.........\r\n---=%@@@@@@@@@@@%%%%##*++=-----------------------------------------------------=+++++++++=:.........\r\n---=+%@@@@@@@@@%#######*+=-----------------------------------------------------=+++++++++=----------\r\n----=#%@@@@@@@%#####*#**+=------------------------------------------------------=++++++++=----------\r\n---=++#@@@@@@%%###***#*++=-------------------------------------------------------++++++++=----------\r\n------+%@@@@@%%%%%%*+***+=---------------------------------=++=------------------=++++++------------\r\n------+%%@@@@@@@%#%%*#**+=-------------------------------=++++++------------------++++++------------\r\n------=*%@@@@@%%####*##*+==----------------------------==+++==--------------------++++++------------\r\n------=*%@@@@@%###*+*#*++=----------------------------=+++=----------------------+++++++------------\r\n------=*%@@@@%%#+==++***+==--------------------------=+++---------===+++*+===-===+++++++------------\r\n------+#%@@@%%#+=-=*###*++=------------------------=+++=----------==+*###**+++++++++++++---=+=------\n\n\n");
                    Console.WriteLine(" ____ ___ ____ _____ _____ __  __    _                                       \r\n/ ___|_ _/ ___|_   _| ____|  \\/  |  / \\                                      \r\n\\___ \\| |\\___ \\ | | |  _| | |\\/| | / _ \\                                     \r\n ___) | | ___) || | | |___| |  | |/ ___ \\                                    \r\n|____/___|____/ |_|_|_____|_|  |_/_/  _\\_\\   ___                             \r\n| |   |_ _| __ )| ____|  _ \\    / \\  |  _ \\ / _ \\                            \r\n| |    | ||  _ \\|  _| | |_) |  / _ \\ | | | | | | |                           \r\n| |___ | || |_) | |___|  _ <  / ___ \\| |_| | |_| |                           \r\n|_____|___|____/|_____|_| \\_\\/_/__ \\_\\____/_\\___/___  _   _  ____  /\\/| ___  \r\n|  _ \\ / \\  |  _ \\    / \\    |  _ \\|  _ \\ / _ \\|  _ \\| | | |/ ___||/\\/ / _ \\ \r\n| |_) / _ \\ | |_) |  / _ \\   | |_) | |_) | | | | | | | | | | |     /_\\| | | |\r\n|  __/ ___ \\|  _ <  / ___ \\  |  __/|  _ <| |_| | |_| | |_| | |___ / _ \\ |_| |\r\n|_| /_/   \\_\\_| \\_\\/_/   \\_\\ |_|   |_| \\_\\\\___/|____/ \\___/ \\____/_/ \\_\\___/ \r\n    _    _   _____ ___    _____ _____ ___  ____    _____ __  _)_)            \r\n   / \\  | | |_   _/ _ \\  |_   _| ____/ _ \\|  _ \\  | ____|  \\/  |             \r\n  / _ \\ | |   | || | | |   | | |  _|| | | | |_) | |  _| | |\\/| |             \r\n / ___ \\| |___| || |_| |   | | | |__| |_| |  _ <  | |___| |  | |             \r\n/_/___\\_\\_____|_| \\___/___ |_| |_____\\___/|_|_\\_\\ |_____|_|  |_|             \r\n / ___|  / \\  |  \\/  | __ )_ _|  / \\  |  _ \\|  _ \\    / \\                    \r\n| |  _  / _ \\ | |\\/| |  _ \\| |  / _ \\ | |_) | |_) |  / _ \\                   \r\n| |_| |/ ___ \\| |  | | |_) | | / ___ \\|  _ <|  _ <  / ___ \\                  \r\n \\____/_/   \\_\\_|  |_|____/___/_/   \\_\\_| \\_\\_| \\_\\/_/   \\_\\                 ");
                    break;
                }

                // Turno do inimigo
                Console.WriteLine("\nTURNO DO AZRAEL:");
                azraelEincinero.Atacar(oliver);

                // Verifica se o jogador morreu após o ataque do inimigo
                if (!oliver.EstáVivo)
                {
                    Console.WriteLine("\nVOCÊ FOI DERROTADO PELO REI DEMÔNIO!\n");
                    Console.WriteLine("                 mo / )\r\n                 |/)\\)\r\n                  /\\_\r\n                  \\__|=\r\n                 (    )\r\n                 __)(__\r\n           _____/      \\\\_____\r\n          |  _     ___   _   ||\r\n          | | \\     |   | \\  ||\r\n          | |  |    |   |  | ||\r\n          | |_/     |   |_/  ||\r\n          | | \\     |   |    ||\r\n          | |  \\    |   |    ||\r\n          | |   \\. _|_. | .  ||\r\n          |                  ||\r\n          |      OLIVER      ||\r\n          |                  ||\r\n  *       | *   **    * **   |**      **\r\n   \\))ejm97/.,(//,,..,,\\||(,,.,\\\\,.((//");
                    break;
                }
                // Mostra o estado atual dos personagens
                oliver.MostrarEstado();
                azraelEincinero.MostrarEstado();

            }
        }
    }
}

class Personagem
{
    public string Nome { get; private set; }
    public int Vida { get; private set; }
    public int Ataque { get; private set; }
    public int Defesa { get; private set; }
    public bool EstáVivo { get { return Vida > 0; } }
    public Personagem(string nome, int vida, int ataque, int defesa)
    {
        Nome = nome;
        Vida = vida;
        Ataque = ataque;
        Defesa = defesa;
    }

    public void Atacar(Personagem alvo)
    {
        int dano = Math.Max(Ataque - alvo.Defesa, 0);
        alvo.Vida -= dano;
        Console.WriteLine($"{Nome} atacou {alvo.Nome} causando {dano} de dano!");
    }

    public void Curar()
    {
        int cura = 20; // Valor arbitrário de cura
        Vida = Math.Min(Vida + cura, 200); // Limite de vida em 100
        Console.WriteLine($"{Nome} se curou em {cura} pontos de vida!");
    }

    public void MostrarEstado()
    {
        Console.WriteLine($"{Nome}: Vida = {Vida}, Ataque = {Ataque}, Defesa = {Defesa}");
    }
}
